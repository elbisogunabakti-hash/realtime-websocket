<?php
class Config {
    public static $DB_HOST = "localhost";
    public static $DB_NAME = "perpus_db";
    public static $DB_USER = "root";
    public static $DB_PASS = "";
    public static $DB_CHARSET = "utf8mb4";
    
    public static $APP_NAME = "REST API PHP";
    public static $DEBUG_MODE = true;
}