<?php
class Buku extends Model {
    public function __construct($db) {
        parent::__construct($db);
        $this->table = "bukus";
    }

    public function getAll() {
        return $this->executeQuery("SELECT * FROM {$this->table} ORDER BY id ASC");
    }

    public function getById($id) {
        $stmt = $this->executeQuery(
            "SELECT * FROM {$this->table} WHERE id = :id",
            [':id' => $id]
        );
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($data) {
        $this->executeQuery(
            "INSERT INTO {$this->table} (judul, penulis, penerbit, tahun_terbit)
             VALUES (:judul, :penulis, :penerbit, :tahun)",
            [
                ':judul' => $data['judul'],
                ':penulis' => $data['penulis'],
                ':penerbit' => $data['penerbit'],
                ':tahun' => $data['tahun_terbit']
            ]
        );
        return ['id' => $this->conn->lastInsertId()] + $data;
    }

    public function update($id, $data) {
        $this->executeQuery(
            "UPDATE {$this->table}
             SET judul=:judul, penulis=:penulis, penerbit=:penerbit, tahun_terbit=:tahun
             WHERE id=:id",
            [
                ':id'=>$id,
                ':judul'=>$data['judul'],
                ':penulis'=>$data['penulis'],
                ':penerbit'=>$data['penerbit'],
                ':tahun'=>$data['tahun_terbit']
            ]
        );
    }

    public function delete($id) {
        $this->executeQuery(
            "DELETE FROM {$this->table} WHERE id=:id",
            [':id'=>$id]
        );
    }
}
