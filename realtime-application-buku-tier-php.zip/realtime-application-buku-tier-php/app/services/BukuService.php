<?php
class BukuService {
    private $buku;

    public function __construct(Buku $buku) {
        $this->buku = $buku;
    }

    public function getAll() {
        return $this->buku->getAll()->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id) {
        return $this->buku->getById($id);
    }

    public function create($data) {
        return $this->buku->create($data);
    }

    public function update($id, $data) {
        $this->buku->update($id, $data);
    }

    public function delete($id) {
        $this->buku->delete($id);
    }
}
