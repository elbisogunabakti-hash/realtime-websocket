<?php

class App {
    private $controller;
    private $method = 'index';
    private $params = [];

    public function __construct() {

        // Preflight CORS
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        $url = $this->parseUrl();

        /*
        |--------------------------------------------------------------------------
        | HANDLE PREFIX /api
        |--------------------------------------------------------------------------
        | Contoh URL:
        | /api/buku/1
        | index.php?url=api/buku/1
        |
        | Kita BUANG 'api'
        */
        if (isset($url[0]) && $url[0] === 'api') {
            unset($url[0]);
            $url = array_values($url);
        }

        /*
        |--------------------------------------------------------------------------
        | CONTROLLER
        |--------------------------------------------------------------------------
        */
        $controllerName = isset($url[0])
            ? ucfirst(strtolower($url[0])) . 'Controller'
            : 'BukuController';

        if (!class_exists($controllerName)) {
            $this->notFound("Controller tidak ditemukan: $controllerName");
        }

        $this->controller = new $controllerName();
        unset($url[0]);
        $url = array_values($url);

        /*
        |--------------------------------------------------------------------------
        | METHOD BASED ON HTTP VERB
        |--------------------------------------------------------------------------
        */
        $httpMethod = $_SERVER['REQUEST_METHOD'];

        switch ($httpMethod) {
            case 'GET':
                if (isset($url[0]) && is_numeric($url[0])) {
                    $this->method = 'show';
                    $this->params = [$url[0]];
                } else {
                    $this->method = 'index';
                }
                break;

            case 'POST':
                $this->method = 'create';
                break;

            case 'PUT':
            case 'PATCH':
                if (isset($url[0]) && is_numeric($url[0])) {
                    $this->method = 'update';
                    $this->params = [$url[0]];
                } else {
                    $this->methodNotAllowed("ID diperlukan untuk UPDATE");
                }
                break;

            case 'DELETE':
                if (isset($url[0]) && is_numeric($url[0])) {
                    $this->method = 'delete';
                    $this->params = [$url[0]];
                } else {
                    $this->methodNotAllowed("ID diperlukan untuk DELETE");
                }
                break;

            default:
                $this->methodNotAllowed("Method $httpMethod tidak didukung");
        }

        /*
        |--------------------------------------------------------------------------
        | EXECUTE
        |--------------------------------------------------------------------------
        */
        if (!method_exists($this->controller, $this->method)) {
            $this->notFound("Method {$this->method} tidak ditemukan di controller");
        }

        call_user_func_array(
            [$this->controller, $this->method],
            $this->params
        );
    }

    private function parseUrl() {
        if (isset($_GET['url'])) {
            return explode('/', trim($_GET['url'], '/'));
        }
        return [];
    }

    private function notFound($message) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => $message
        ], JSON_PRETTY_PRINT);
        exit();
    }

    private function methodNotAllowed($message) {
        http_response_code(405);
        echo json_encode([
            'success' => false,
            'message' => $message
        ], JSON_PRETTY_PRINT);
        exit();
    }
}
